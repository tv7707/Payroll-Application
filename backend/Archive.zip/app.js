// Importing express package.
const express = require('express');
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const app = express();

// Making Database Connection.
mongoose.connect("mongodb+srv://tejal:RhWA18Iy3UU7EOFM@cluster0-vyugq.mongodb.net/payroll?retryWrites=true").
then(() => {
  console.log("Connection Successful!");
})
.catch(() => {
  console.log("Connection Failed");
});

// Mongoose Employee Model
const Employee = require("./models/employee");
// Mongoose Salary Model
const Salary = require("./models/salary");

//Adding headers to responses to enable CORS.
app.use(function(req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    'GET, POST, PATCH, PUT, DELETE, OPTIONS'
    );
  next();
});

// Calling the middleware bodyparser for Json Objects.
app.use(bodyParser.json());

/* Post Request
 * Using body parser to get the data from the response body.
*/
app.post("/employees", (req, res, next) => {
  //Creating an employee object using the model.
  const employee = new Employee({
    name: req.body.name,
    basePay : req.body.basePay,
    deductions: req.body.deductions,
    netPay: req.body.netPay
   });
   console.log(employee);
   employee.save();
});

/* Get Request to the database.
 * Using find method of model to fetch the employee data
 * Sending the data in form of Json.
 **/
app.get('/employees' ,(req, res, next) => {
Employee.find().then(
  (documents) => {
    res.status(200).json({
      message: 'Employee Data Fed Successfully!',
      employeesData : documents
    });
  }
)
});



/* Post Request
 * Using body parser to get the data from the response body.
*/
app.post("/employee/salary", (req, res, next) => {
  //Creating an employee object using the model.
    const employeeSalary = new Salary({
    employeeId: req.body._id,
    deductions : req.body.deductions,
    deductionAmount      : req.body.amount
   });
   console.log(employeeSalary);
   employeeSalary.save();
});


/* Get Request to the database.
 * Using find method of model to fetch the salary data
 * Sending the data in form of Json.
 **/
app.get('/employee/salary/:id' , (req, res, next) => {
  param_id = req.params.id.toString();
  Salary.find({employeeId: param_id}).then(
    (documents) => {
      console.log(documents);
      res.status(200).json({
        message: ' Salary Data Fed Successfully!',
        salaryData : documents
      });
    }
  )
});

// Put request to update the data of the existing employee.
app.put('/employees/:_id' , (req, res, next) => {
  const employee = new Employee({
    _id: req.body._id,
    name: req.body.name,
    basePay : req.body.basePay,
    deductions: req.body.deductions,
    netPay: req.body.netPay
   });
   Employee.updateOne({_id: req.params._id}, employee).then(result => {
    console.log(result);
    res.status(200).json({
      message: "Employee Updated!"
    });
   });
})

// Deleting employees.
app.delete("/employees/:_id", (req, res, next) => {
  //console.log(req.params._id);
  Employee.deleteOne({_id: req.params._id}).then((result) => {
    console.log(result);
    res.status(200).json({
      message: "Employee Deleted!"
    });
  });
});


// Exporting app to server.js file.
module.exports = app;
