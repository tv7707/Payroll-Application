const mongoose = require("mongoose");

// Creating a schema to structure the employee data.
const empDataSchema = mongoose.Schema({
  name: {type: String, required: true },
  basePay: {type: String, required: true },
  deductions: {type: String },
  netPay: {type: String }
});


module.exports = mongoose.model("Employee" , empDataSchema)
